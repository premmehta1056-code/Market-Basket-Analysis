import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules

# Load dataset
data = pd.read_csv('transactions.csv')

# Transform data into transaction matrix
basket = data.groupby(['TransactionID', 'ProductName'])['ProductName'].count().unstack().fillna(0)
basket = basket.applymap(lambda x: 1 if x > 0 else 0)

# Generate frequent itemsets
frequent_itemsets = apriori(basket, min_support=0.2, use_colnames=True)

# Generate association rules
rules = association_rules(frequent_itemsets, metric='lift', min_threshold=1.0)

# Sort by confidence
rules = rules.sort_values(by='confidence', ascending=False)

# Display top rules
print(rules.head())
