-- SQL script for creating and loading transaction data
CREATE TABLE transactions (
    TransactionID INT,
    ProductName VARCHAR(50)
);

-- Example Insertions
INSERT INTO transactions VALUES (1, 'Milk');
INSERT INTO transactions VALUES (1, 'Bread');
INSERT INTO transactions VALUES (1, 'Butter');
INSERT INTO transactions VALUES (2, 'Beer');
INSERT INTO transactions VALUES (2, 'Diaper');
INSERT INTO transactions VALUES (3, 'Milk');
INSERT INTO transactions VALUES (3, 'Diaper');
INSERT INTO transactions VALUES (3, 'Beer');
INSERT INTO transactions VALUES (3, 'Bread');
