# Market Basket Analysis Report

## 1. Objective
To identify products frequently purchased together to improve cross-selling and bundling strategies.

## 2. Data Summary
- Transactional dataset with multiple products per transaction.
- Each transaction contains items purchased together.

## 3. Model Used
- **Apriori Algorithm** for frequent itemset mining.
- **Association Rules** for identifying strong product relationships.

## 4. Key Findings
1. Bread & Butter, Milk & Eggs are common pairs.
2. Lift > 1.5 indicates strong association strength.
3. Rules with high confidence show reliable purchasing patterns.

## 5. Business Strategies
- Create combo offers and bundles for frequently bought-together items.
- Place associated items near each other in stores.
- Design targeted marketing campaigns to promote cross-selling.
