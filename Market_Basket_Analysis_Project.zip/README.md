# Market Basket Analysis

This project identifies frequently purchased product combinations using **Association Rule Mining (Apriori Algorithm)**.

## 📘 Overview
- **Goal**: Discover product combinations often bought together.
- **Tools Used**: Python (Apriori Algorithm, MLxtend), SQL
- **Outcome**: Actionable insights for cross-selling and product bundling.

## 🚀 Features
1. Data preprocessing and transaction transformation
2. Frequent itemset mining using Apriori
3. Rule generation with Support, Confidence, and Lift metrics
4. Visualization of association patterns
5. SQL queries for data aggregation and product frequency analysis

## 🧠 Steps to Run
```bash
# Clone the repository
git clone https://github.com/yourusername/Market-Basket-Analysis.git
cd Market-Basket-Analysis

# Install dependencies
pip install -r requirements.txt

# Run the notebook
jupyter notebook market_basket_analysis.ipynb
```

## 🧩 Project Structure
```
├── README.md
├── requirements.txt
├── market_basket_analysis.ipynb
├── data.sql
├── apriori_model.py
├── report.md
```

## 📊 Results
- Found frequent product pairs such as: **Bread & Butter**, **Milk & Eggs**
- Strong rules with **Lift > 1.5**
- Helps design product placement and promotional offers

## 💡 Business Insights
1. Frequently bought-together items can be bundled for promotions.
2. Product placement near each other can increase sales.
3. Cross-selling opportunities can be improved via recommendation systems.

---
👨‍💻 Developed by [Your Name]
